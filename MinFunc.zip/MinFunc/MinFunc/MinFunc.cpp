// MinFunc.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
int main()
{
	//float income = 40000.00;
	//float threshold = 120000.00;

	float tax_rate = 0;
	if (income < threshold) {
		tax_rate = 0.10;
	}
	else {
		tax_rate = 0.10 + ((income - threshold) / income);
	}

	float num = tax_rate * income;
	printf("Income: %6.2f \n", income);
	printf("Threshold: %6.2f \n", threshold);
	printf("Tax Rate: %6.2f \n", tax_rate);
	printf("Output: %6.2f", num);
	
	getchar();
	return 0;


	//Enter a number to chceck the if its divisable by 3
	//Use of if and switch statements to show how each one works
	/*int num;
	//int remainder = num % 3;
	printf("Enter a number: ");
	scanf("%d", &num);//input a number
	if (remainder)//is num 
	{
		printf("if statement: %d is divisable by 3 \n", num);
		getchar();
	}
	else 
	{
		printf("if statement: %d is not divisable by 3 \n", num);
		getchar();
	}
	
	switch (remainder)
	{	
		case 0:
			printf("switch: %d is divisible by 3 \n", num);
			getchar();
			break;											    		
		default:
			printf("switch: %d is not divisible by 3: \n", num);
			getchar();
			break;
	}
	getchar();
	return 0;
	*/
}
    

