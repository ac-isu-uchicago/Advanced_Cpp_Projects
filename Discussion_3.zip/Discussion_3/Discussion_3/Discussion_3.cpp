// Discussion_3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


int main()
{
	int max, min, x, y;
	printf("Enter numbers to compare value: ");
	scanf("%d %d", &x, &y);
	if (x > y && y == 0)
	{
		printf("Your x is a max value");

		printf("%d", &x);
		getchar();
	}
	else if (y > x && x == 0);
	{
		printf("%d", &y);
		getchar();
	}

	getchar();
	printf("Please exit the program");
    return 0;
}

