//Austin Castellino
//Assignment_07 - Bank Simulation
//CS50
//10/31/2018
//	Description:
//		Create an bank simulation that has deposit, withdrawals, and account infomation.
//		Demonstrate the use of function scoop in between functions. Show how to loop a 
//		switch menu to provide a better user experience. 

#include<stdio.h>

#include<stdlib.h>

//function declaration

float View_Balance(float user_balance);

float Deposit(float user_balance, float depoist);

float Withdrawl(float user_balance, float withdraw);

void Quit();



int main()

{
	//variables

	float user_balance = 100000;

	float deposit, withdraw;

	int switchint; //used for switch function and user input.

	int exit_00;

	//start of do while loop

	do
	{
		printf("1. Show Balance.\n");

		printf("2. Make a Deposit.\n");

		printf("3. Make a Withdrawl.\n");

		printf("4. Exit Program.\n");

		printf("Please select a choice \n");

		scanf("%d", &switchint);


		//switch to user switchint

		switch (switchint) //changes menu

		{

		case 1:

			//call to function

			View_Balance(user_balance);

			continue;

		case 2:

			do
			{
				printf("Enter the amount to deposit: ");

				scanf("%f", &deposit);


				//error condition

				if (deposit < 0 || deposit>10000)
				{

					printf("Sorry Amount is not accepted.\n");

				}

			} while (deposit < 0 || deposit>10000);

			

			user_balance = Deposit(user_balance, deposit);

			//Display balance

			printf("Current Balance is: %0.2lf\n", user_balance);

			continue;

		case 3:

			do
			{

				//display message

				printf("Enter the amount to withdraw: ");

				scanf("%f", &withdraw);


				if (withdraw<0 || user_balance < 0)
				{

					printf("Sorry You are not allowed to withdraw.\n");

				}

			} while (withdraw<0 || user_balance<0);

			//call to function

			user_balance = Withdrawl(user_balance, withdraw);

			//Display current balance

			printf("Current Balance is: %0.2lf\n", user_balance);

			continue;


		case 4:

			//call to function
			Quit();

			break;
		}

	} while (switchint <= 4);


	return 0;

}

//function

float View_Balance(float user_balance)

{

	//Display current Balance

	printf("Current Balance is: %0.2lf\n", user_balance);

}
int exit_00(int exit) {



}

//function definition

float Deposit(float user_balance, float deposit)

{

	//calculate new balance

	user_balance = user_balance + deposit;

	return user_balance;

}

//function definition

float Withdrawl(float user_balance, float withdraw)

{

	//calculate new balance

	user_balance = user_balance - withdraw;

	return user_balance;

}

void Quit()

{
	printf("Thank you..!! Exiting the program.\n\n");
	char c1, c2;
	c1 = getchar(); // get first input
	printf("Please press enter to exit. \n");
	c2 = getchar();
	if (c1 == '\n' && c2 == '\n') // if post inputs are enter
		exit(1); // exit

	void exit(int status);
}

//Notes
//printf and scanf, scanf_s gives program with memeory addresses.
//leftover data from previous complations will affect a new programs 
//which do not have the statements written.
//Switch statments; looping menus
//difficult to program the exit function

