//Assignment10ACastellinoCS50
//Austin Castellino
//CS 50
//Program 10:
//* Write a function to take a string of no more than 50 characters and a        *
//	character and returns the count of a letter the user inputs.If the letter   
//	is not found, the function returns - 1.                                                                                                                  
//	Use the function in main to get two inputs from the user, a sentence and     
//	a character, then show the count of that character.                          


#include "stdafx.h"
#include <stdio.h>
#include <string.h>

//func declaration
int ccount(char word[], int limit, char character);

int main()
{
	printf("Hi, Enter a string of chacaters no longer than 50:\n");

	//user input sentence
	char input[51];
	fgets(input, 51, stdin);

	printf("Enter a Letter to count: \n");

	//user input letter
	char user_char; 
	scanf_s("%c", &user_char);

	//function to read the letters of input
	int len = strlen(input);
	int result = ccount(input, len, user_char);

	if (result != -1) {
		printf("I found %c %d times. \n", user_char, result);
	}
	else {
		printf("%c was not found \n", user_char);
	}

    return 0;													  
}

int ccount(char word[], int limit, char character) 
{
	int count = 0;
	for (int i = 0; i < limit; i++)
		//check index of word to the character the user entered above
		if (word[i] == character) {
			count++;
		}
	
	if (count == 0) {
		return -1;
	}
	return count;
}


